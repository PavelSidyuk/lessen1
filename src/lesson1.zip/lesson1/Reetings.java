package lesson1;

public class Reetings {
    public static void main(String[] args){


            System.out.println("Привет, Вася!" );

    }


}
