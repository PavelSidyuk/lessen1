package lesson1;

import java.util.Scanner;

public class TrueFalse {


    public static void main(String[] args){

        int a = 5;
        int b = 5;
        int c = (a + b); {
            if(c <=20 && c >=10){
                System.out.println(true);
            }
            else  {
                System.out.println(false);
            }
        }











    }
}
