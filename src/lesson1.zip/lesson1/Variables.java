package lesson1;

public class Variables {
    public static void main(String[] args)  {
        byte a = 127;
        short a1 = 500;
        int a2 = 100000;
        long a3 =300000000;
        float b1 = 10.15f;
        double b2 = 3000.8888;
        char c1 = 10000;
        boolean d1 = true;
        boolean d2 = false;





    }
}
