package lesson1;

public class IsNegative {
    public static void main(String[] args) {
    }

    public static boolean isNegative(int x) {
         int a = 2;
        if (a >= 0) {
            return false;} else {
            return (true);
        }




      /*  if (a >= 0) {
            return false;
        } else {
            return true;
        }*/


    }
}
