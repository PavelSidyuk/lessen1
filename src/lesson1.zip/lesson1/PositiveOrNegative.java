package lesson1;

public class PositiveOrNegative {
    public static void main(String[] args){

      int a = 1100000;
      if (a >= 0){
          System.out.println("Число положительное");
      } else {
          System.out.println("Число отрицательное");
      }









    }
}
